import MainContent from "./pages/main/Index";

function App() {
  return (
    <>
      <MainContent />
    </>
  );
}

export default App;
